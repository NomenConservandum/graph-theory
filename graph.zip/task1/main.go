package main

func main() {
	cli := NewCLI()
	cli.Run()
}
